# Smart Onion Storage

A smart storage system for onions using **ESP8266**, **DHT11**, **MQ135 gas sensor**, **I2C LCD**, and **Blynk**.  
It monitors temperature, humidity, and gases (Ethylene, NH3, H2S) and automatically controls a fan to maintain safe storage conditions.

## 📌 Features
- Real-time temperature and humidity monitoring
- Gas detection (Ethylene, NH3, H2S)
- Automatic fan control based on thresholds
- Stage-wise onion freshness alerts
- Blynk dashboard integration for remote monitoring
- I2C LCD display for local updates

## 🔧 Hardware Required
- ESP8266 (NodeMCU or similar)
- DHT11 Temperature & Humidity Sensor
- MQ135 Gas Sensor
- Relay Module (to control fan)
- 16x2 I2C LCD Display
- Fan (or equivalent load)
- Jumper wires and breadboard

## ⚙️ Wiring

| Sensor/Module | ESP8266 Pin |
|---------------|------------|
| DHT11 Data    | D8         |
| MQ135 Analog  | A0         |
| Relay         | D5         |
| LCD SDA       | D2         |
| LCD SCL       | D1         |

## Team Members
- Ravikanth
- Adarsh
- Rahul
- Zaheer
- Chaitanya Priya
- Teja
